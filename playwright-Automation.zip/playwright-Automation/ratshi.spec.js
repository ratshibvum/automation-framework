const { test, expect } = require('@playwright/test');

test('homepage should have correct title', async ({ page }) => {
  await page.goto('https://vhavhundosolutions.com');
  await expect(page).toHaveTitle(/Vhavhundo/i);
});
