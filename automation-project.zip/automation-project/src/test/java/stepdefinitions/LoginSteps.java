package stepdefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class LoginSteps {
    WebDriver driver;

    @Given("I am on the login page")
    public void i_am_on_the_login_page() {
        driver = new ChromeDriver();
        driver.get("http://example.com/login");
    }

    @When("I enter valid credentials")
    public void i_enter_valid_credentials() {
        WebElement username = driver.findElement(By.id("username"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.id("loginBtn"));

        username.sendKeys("testuser");
        password.sendKeys("password123");
        loginButton.click();
    }

    @Then("I should see the dashboard")
    public void i_should_see_the_dashboard() {
        String expectedUrl = "http://example.com/dashboard";
        Assert.assertEquals(driver.getCurrentUrl(), expectedUrl);
        driver.quit();
    }
}