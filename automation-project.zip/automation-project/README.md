# Automation Project

## Tools Used
✅ Cucumber  
✅ TestNG (parallel)  
✅ Selenium  
✅ Git  
✅ Jenkins  
✅ Docker  
✅ Allure Reports

## Run Tests Locally
```bash
mvn clean test -Dsurefire.suiteXmlFiles=testng.xml
```

## Run Tests with Docker
```bash
docker build -t automation-tests .
docker run automation-tests
```

## Run with Docker Compose
```bash
docker-compose up --abort-on-container-exit
```

## CI/CD Pipeline
Jenkins pipeline builds & runs tests in Docker on every push.  
Test results are published as TestNG + Allure reports.